#include <ilcplex/ilocplex.h>
#include <ilcplex/ilocplexi.h>
#include <time.h>
#include <math.h>
#include <process.h>
#include <conio.h>
#include <dos.h>
#include <memory.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>

using namespace std;
ILOSTLBEGIN
ofstream outfile;

typedef IloArray<IloIntArray>    IntMatrix;
typedef IloArray<IloIntVarArray> IntVarMatrix;
typedef IloArray<IloNumArray>    NumMatrix;
typedef IloArray<NumMatrix>      NumMatrix3d;
typedef IloArray<IloNumVarArray> NumVarMatrix;
typedef IloArray<NumVarMatrix>   NumVarMatrix3d;
typedef IloArray<IntVarMatrix>   IntVarMatrix3d;
typedef IloArray<IloArray<IloArray<IloNumVarArray>>> NumVarArray4;//��ά����

#define  largeNum      100000      //A large constant value
#define  smallNum      0.01        //A small constant value
#define  myTiLim	  1800        //limit time
#define  bigM	       100        //a big positive value 
#define  nbNode      51      //��������
#define  nbTeam     11  //ά����������
#define  P       1     //���ģ��
#define  f1       5          //ά����������
#define  f2        1000          //ά����������
#define  f3        50         //ά����������
#define  vf            2400         //fire-fighting speed m/min
int  Index;
int  numtest = 1;
int  numth;
int  Numth;
double upperbound;
double lowerbound;
double LANMTA;
double minf1, maxf1, minf2, maxf2;
double OBJ1, OBJ2, MAX;

double      dis[nbNode + 1][nbNode + 1];    //network state 10000 or 1
double      Vm[nbTeam]; // ��ȡÿ��ά��������ʻ���ٶ�

double   p[nbNode + 1]; // ��ȡÿ��������ά��ʱ��
double     Q[nbTeam];// ��ȡÿ������������ά����������
double   u[nbNode + 1];// ��ȡÿ������Ԥ���RUL

double   Tstart = 0;//initial fire-fighting time

double   AvgTD = 0;
double   AvgCons = 0;
double   AvgVar = 0;
char instance[2000];

//char* resultDir = "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P2-RESS-15-3-revised.txt"; //output results
//ofstream resufile(resultDir, ios::app); //open input results files
void initialize()
{
	int i, j;
	//char* FNstr;//txt file names
	char NEWinstance[200];
	_snprintf_s(NEWinstance, sizeof(NEWinstance), "E:\\paper\\Aero-engine-maintenance\\IISE-shuju\\IISE-%d-%d-data1.txt", nbNode, nbTeam);
	ifstream fin(NEWinstance);


	//FNstr = "E:\\paper\\Aero-engine-maintenance\\RESS-shuju\\RESS-17-5.txt";

	ifstream infile(NEWinstance, ios::in);//open your data file
	if (!infile) {
		cerr << "Open error:" << endl;
		exit(1);
	}

	//��ȡ���ݾ���
	for (i = 0; i < nbNode + 1; i++)
	{
		for (j = 0; j < nbNode + 1; j++)
		{
			infile >> dis[i][j];
			cout << dis[i][j] << " ";
		}
		cout << endl;
	}


	cout << endl;
	for (i = 0; i < nbTeam; i++) // ��ȡÿ��ά������������ά����������
	{
		infile >> Q[i];
		cout << Q[i] << "\t";
	}
	cout << endl;
	for (i = 0; i < nbTeam; i++)// ��ȡÿ��ά��������ʻ���ٶ�
	{
		infile >> Vm[i];
		cout << Vm[i] << "\t";
	}



	cout << endl;
	for (i = 0; i < nbNode + 1; i++) // ��ȡÿ��������ά��ʱ��
	{
		infile >> p[i];
		cout << p[i] << "\t";
	}
	cout << endl;
	for (i = 0; i < nbNode + 1; i++) // ��ȡÿ������Ԥ���RUL
	{
		infile >> u[i];
		cout << u[i] << "\t";
	}
	cout << endl;
	infile.close();
	return;
}


int FindOptM_Cplex_1()
{

	int i, j, m;
	char instance[2000];
	sprintf_s(instance, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P1-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream resufile(instance, ios::app);
	float objvalue1, objvalue2;
	IloEnv env;
	try
	{
		printf("problem1\n\n\n\n ");
		resufile << "problem1 : " << endl;
		IloModel model(env);
		//======Decision Variables Definition ==========//

		//======Decision Variables Definition ==========//
		NumVarMatrix3d X(env, nbTeam); //������߱�������
		for (m = 0; m < nbTeam; m++)
		{
			X[m] = NumVarMatrix(env, nbNode + 1);
			for (i = 0; i < nbNode + 1; i++)
				X[m][i] = IloNumVarArray(env, nbNode + 1, 0, 1, ILOINT); //FLOAT INT
		}
		IloNumVar Cmax(env, 0, IloInfinity);//total completion time

		IloNumVarArray C(env, nbNode + 1, 0, IloInfinity); //���岿����ά�����ʱ��

		//======formulation ==========//
		model.add(IloMinimize(env, Cmax));// minimizing the total completion time


		IloExpr sumPass(env);//Լ��1  ��ʾÿ������ֻ����һ��ά�������ṩ����
		for (j = 1; j < nbNode + 1; j++)
		{
			for (m = 0; m < nbTeam; m++)
				for (i = 0; i < nbNode + 1; i++)
					if (i != j)
					{
						sumPass += X[m][i][j];
					}
			model.add(sumPass == 1);
			sumPass.clear();
		}


		IloExpr sumP1(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP1 += X[m][0][i];
			}
			model.add(sumP1 == 1);
			sumP1.clear();
		}
		IloExpr sumP2(env);//Լ��3  ��ʾÿ����Ԯ���鶼���Իص���Ԯ����
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP2 += X[m][i][0];
			}
			model.add(sumP2 == 1);
			sumP2.clear();
		}


		IloExpr sumPre(env);//Լ��5 ����ƽ��Լ������Ч����ʽ
		IloExpr sumAft(env);
		for (m = 0; m < nbTeam; m++)
			for (j = 1; j < nbNode + 1; j++)
			{
				for (i = 0; i < nbNode + 1; i++)
				{
					sumPre += X[m][i][j];
					sumAft += X[m][j][i];
				}
				model.add(sumPre == sumAft);
				model.add(sumPre <= 1);
				model.add(sumAft <= 1);
				sumPre.clear();
				sumAft.clear();
			}

		IloExpr sumTime(env);//Լ��6 ������ʻʱ��Լ��
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					sumTime += X[m][i][j];
			model.add(sumTime <= Q[m]);
			sumTime.clear();
		}


		for (m = 0; m < nbTeam; m++)//��Ԯ���ȼ�Լ��
		{
			for (i = 1; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					if (i > j)
					{
						model.add(X[m][i][j] == 0);
					}

		}

		IloExpr sumP01(env);//Լ��2  ά�����ȼ�Լ��
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbTeam + 1; i++)
			{
				sumP01 += X[m][0][i];
			}
		model.add(sumP01 == nbTeam);
		sumP1.clear();



		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j] + X[m][j][i] <= 1);

		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j]);

		/*=======================����ά��ʱ��============================*/

		model.add(C[0] == 0);

		//for (i = 1; i < nbTeam + 1; i++)
		//{
		//	//IloExpr sums1(env);
		//	for (m = 0; m < nbTeam; m++)
		//	/*{
		//		sums1 += dis[0][i] / Vm[m] * X[m][0][i];
		//	}*/
		//	model.add(C[i] >= dis[0][i] / Vm[m] * X[m][0][i] + p[i]);
		//	//sums1.clear();
		//}

		for (i = 1; i < nbTeam + 1; i++)
		{
			IloExpr sums1(env);
			for (m = 0; m < nbTeam; m++)
			{
				sums1 += dis[0][i] / Vm[m] * X[m][0][i];
			}
			model.add(C[i] >= sums1 + p[i]);
			sums1.clear();
		}

		//IloExpr sumP11(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		//for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
		//	for (j = 0; j < nbNode + 1; j++)
		//	{
		//		for (m = 0; m < nbTeam; m++)
		//			//sumP11 += X[m][j][i];	
		//		if (i > j)
		//		{
		//			sumP11 += X[m][j][i];
		//		}
		//		model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (sumP11 - 1));
		//		sumP11.clear();
		//		
			//}

		for (i = 1; i < nbNode + 1; i++)// ����ά��������ɲ���i��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					if (i > j)
					{
						model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (X[m][j][i] - 1));
						//model.add(C[i] <= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (1 - X[m][j][i]));
					}


		for (i = 1; i < nbNode + 1; i++)
		{
			model.add(Cmax >= C[i]);
		}



		IloExpr temp8(env); //��Ч����ʽ1
		for (j = 1; j < nbNode + 1; j++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (m = 0; m < nbTeam; m++)
				{
					if (i != j)
					{
						temp8 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp8);
			temp8.clear();
		}


		IloExpr temp81(env);//��Ч����ʽ2
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
				{
					if (i != j)
					{
						temp81 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp81);
			temp81.clear();
		}




		//IloExpr sumP13(env);//Լ��2  ģ��P2��
		//for (i = 1; i < nbNode + 1; i++)
		//{
		//	for (j = 0; j < nbNode + 1; j++)
		//		for (m = 0; m < nbTeam; m++)
		//		{
		//			sumP13 += X[m][j][i];
		//		}

		//	model.add(C[i] >= (u[i] + p[i]) * sumP13);
		//	sumP13.clear();
		//}



		//=====solve the model and parameter setting====//
		IloCplex cplex(model); // or IloCplex cplex(env); cplex.extract(model);
		cplex.setParam(IloCplex::TiLim, myTiLim);
		cplex.setParam(IloCplex::ClockType, 1);
		cplex.setParam(IloCplex::WorkMem, 512);
		cplex.setParam(IloCplex::TreLim, 1024);
		cplex.setParam(IloCplex::NodeFileInd, 2);//to aviod out of memory 
		cplex.setParam(IloCplex::Symmetry, 2);
		cplex.exportModel("FFS.lp");
		cplex.solve();

		if (!cplex.solve())
		{
			cout << "Cplex_solve error!" << endl;
			throw(-1);
		}
		resufile << endl;
		resufile << " results " << endl;
		cout << "\n\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		cout << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		resufile << "\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		resufile << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		resufile << "iterations:  " << cplex.getNiterations() << "  " << "searched nodes: " << cplex.getNnodes() << endl;


		double AcDri1[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri1[m] = 0;
			cout << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						cout << i << "  " << j << "   ";
						AcDri1[m] += dis[i][j];
					}
			cout << "   " << AcDri1[m];
		}
		resufile << " Route " << endl;
		double AcDri[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri[m] = 0;
			resufile << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						resufile << i << "  " << j << "   ";
						AcDri[m] += dis[i][j];
					}
			resufile << "   " << AcDri[m];
		}

		resufile << " C_j " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				resufile << cplex.getValue(C[j]) << "  ";
			}
		cout << endl;
		cout << " ά�����ʱ�� " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				cout << cplex.getValue(C[j]) << "  ";
			}

		double CC = 0;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				CC += f3 * cplex.getValue(C[j]);
			}
		resufile << "ά���ɱ� " << CC << endl;
		//====================================================
		objvalue1 = cplex.getValue(Cmax);
		objvalue2 = 0;
		double ff2 = 0;
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					objvalue2 += f1 * dis[i][j] * cplex.getValue(X[m][i][j]);
		for (j = 1; j < nbNode + 1; j++)
			ff2 += f3 * cplex.getValue(C[j]);

		minf1 = objvalue1;
		maxf2 = objvalue2 + f2 * nbTeam + ff2;
		upperbound = maxf2;



	}
	catch (IloException& e) { cerr << " ERROR: " << e << endl; }
	catch (...) { cerr << " ERROR" << endl; }
	env.end();
	return 0;
}

int FindOptM_Cplex_2()
{
	int i, j, m;
	char instance[2000];
	sprintf_s(instance, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P1-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream resufile(instance, ios::app);
	float objvalue1, objvalue2;
	IloEnv env;
	try
	{
		printf("problem2 \n\n\n");
		resufile << "problem2 : " << endl;
		IloModel model(env);
		//======Decision Variables Definition ==========//
		char varName[100];

		NumVarMatrix3d X(env, nbTeam); //������߱�������
		for (m = 0; m < nbTeam; m++)
		{
			X[m] = NumVarMatrix(env, nbNode + 1);
			for (i = 0; i < nbNode + 1; i++)
				X[m][i] = IloNumVarArray(env, nbNode + 1, 0, 1, ILOINT); //FLOAT INT
		}
		IloNumVar Cmax(env, 0, IloInfinity);//total completion time

		IloNumVarArray C(env, nbNode + 1, 0.0, IloInfinity); //���岿����ά�����ʱ��

		//======formulation ==========//
		//Objective 1
		//IloObjective obj1(env, Cmax, IloObjective::Minimize);
		//model.add(obj1);
		//model.add(IloMinimize(env, Cmax));// minimizing the total completion time

		IloExpr obj2(env);
		IloExpr obj22(env);
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					obj2 += f1 * dis[i][j] * X[m][i][j];
		for (j = 1; j < nbNode + 1; j++)
			obj22 += f3 * C[j];
		//model.add(IloMinimize(env, obj2 + f2 * nbTeam));
		model.add(IloMinimize(env, obj2 + f2 * nbTeam + obj22));

		IloExpr sumPass(env);//Լ��1  ��ʾÿ������ֻ����һ��ά�������ṩ����
		for (j = 1; j < nbNode + 1; j++)
		{
			for (m = 0; m < nbTeam; m++)
				for (i = 0; i < nbNode + 1; i++)
					if (i != j)
					{
						sumPass += X[m][i][j];
					}
			model.add(sumPass == 1);
			sumPass.clear();
		}


		IloExpr sumP1(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP1 += X[m][0][i];
			}
			model.add(sumP1 == 1);
			sumP1.clear();
		}
		IloExpr sumP2(env);//Լ��3  ��ʾÿ����Ԯ���鶼���Իص���Ԯ����
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP2 += X[m][i][0];
			}
			model.add(sumP2 == 1);
			sumP2.clear();
		}


		IloExpr sumPre(env);//Լ��5 ����ƽ��Լ������Ч����ʽ
		IloExpr sumAft(env);
		for (m = 0; m < nbTeam; m++)
			for (j = 1; j < nbNode + 1; j++)
			{
				for (i = 0; i < nbNode + 1; i++)
				{
					sumPre += X[m][i][j];
					sumAft += X[m][j][i];
				}
				model.add(sumPre == sumAft);
				model.add(sumPre <= 1);
				model.add(sumAft <= 1);
				sumPre.clear();
				sumAft.clear();
			}

		IloExpr sumTime(env);//Լ��6 ������ʻʱ��Լ��
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					sumTime += X[m][i][j];
			model.add(sumTime <= Q[m]);
			sumTime.clear();
		}


		for (m = 0; m < nbTeam; m++)//��Ԯ���ȼ�Լ��
		{
			for (i = 1; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					if (i > j)
					{
						model.add(X[m][i][j] == 0);
					}

		}

		IloExpr sumP01(env);//Լ��2  ά�����ȼ�Լ��
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbTeam + 1; i++)
			{
				sumP01 += X[m][0][i];
			}
		model.add(sumP01 == nbTeam);
		sumP1.clear();



		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j] + X[m][j][i] <= 1);

		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j]);

		/*=======================����ά��ʱ��============================*/

		model.add(C[0] == 0);

		for (i = 1; i < nbTeam + 1; i++)
		{
			//IloExpr sums1(env);
			for (m = 0; m < nbTeam; m++)
				/*{
					sums1 += dis[0][i] / Vm[m] * X[m][0][i];
				}*/
				model.add(C[i] >= dis[0][i] / Vm[m] * X[m][0][i] + p[i]);
			//sums1.clear();
		}



		for (i = 1; i < nbNode + 1; i++)// ����ά��������ɲ���i��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					if (i > j)
					{
						model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (X[m][j][i] - 1));
						//model.add(C[i] <= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (1 - X[m][j][i]));
					}


		for (i = 1; i < nbNode + 1; i++)
		{
			model.add(Cmax >= C[i]);
		}

		IloExpr temp8(env); //��Ч����ʽ1
		for (j = 1; j < nbNode + 1; j++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (m = 0; m < nbTeam; m++)
				{
					if (i != j)
					{
						temp8 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp8);
			temp8.clear();
		}


		IloExpr temp81(env);//��Ч����ʽ2
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
				{
					if (i != j)
					{
						temp81 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp81);
			temp81.clear();
		}

		//IloExpr sumP13(env);//Լ��2  ģ��P2��
		//for (i = 1; i < nbNode + 1; i++)
		//{
		//	for (j = 0; j < nbNode + 1; j++)
		//		for (m = 0; m < nbTeam; m++)
		//		{
		//			sumP13 += X[m][j][i];
		//		}

		//	model.add(C[i] >= (u[i] + p[i]) * sumP13);
		//	sumP13.clear();
		//}

		//for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
		//	for (j = 0; j < nbNode + 1; j++)
		//		for (m = 0; m < nbTeam; m++)
		//			model.add(C[i] >= u[i] + p[i]);

		//=====solve the model and parameter setting====//
		IloCplex cplex(model); // or IloCplex cplex(env); cplex.extract(model);
		cplex.setParam(IloCplex::TiLim, myTiLim);
		cplex.setParam(IloCplex::ClockType, 1);
		cplex.setParam(IloCplex::WorkMem, 512);
		cplex.setParam(IloCplex::TreLim, 1024);
		cplex.setParam(IloCplex::NodeFileInd, 2);//to aviod out of memory 
		cplex.setParam(IloCplex::Symmetry, 2);
		cplex.exportModel("FFS.lp");
		cplex.solve();

		if (!cplex.solve())
		{
			cout << "Cplex_solve error!" << endl;
			throw(-1);
		}
		resufile << endl;
		resufile << " results " << endl;
		cout << "\n\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		cout << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		resufile << "\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		resufile << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		resufile << "iterations:  " << cplex.getNiterations() << "  " << "searched nodes: " << cplex.getNnodes() << endl;


		double AcDri1[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri1[m] = 0;
			cout << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						cout << i << "  " << j << "   ";
						AcDri1[m] += dis[i][j];
					}
			cout << "   " << AcDri1[m];
		}
		resufile << " Route " << endl;
		double AcDri[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri[m] = 0;
			resufile << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						resufile << i << "  " << j << "   ";
						AcDri[m] += dis[i][j];
					}
			resufile << "   " << AcDri[m];
		}

		resufile << " C_j " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				resufile << cplex.getValue(C[j]) << "  ";
			}
		cout << endl;
		cout << " ά�����ʱ�� " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				cout << cplex.getValue(C[j]) << "  ";
			}
		double CC = 0;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				CC += f3 * cplex.getValue(C[j]);
			}
		resufile << "ά���ɱ� " << CC << endl;

		//==========================================
		objvalue1 = cplex.getValue(Cmax);

		objvalue2 = 0;
		double ff2 = 0;
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					objvalue2 += f1 * dis[i][j] * cplex.getValue(X[m][i][j]);
		for (j = 1; j < nbNode + 1; j++)
			ff2 += f3 * cplex.getValue(C[j]);
		maxf1 = objvalue1;
		minf2 = objvalue2 + f2 * nbTeam + ff2;
		lowerbound = objvalue2 + f2 * nbTeam + ff2;

	}
	catch (IloException& e) { cerr << " ERROR: " << e << endl; }
	catch (...) { cerr << " ERROR" << endl; }
	env.end();
	return 0;
}

int FindOptM_Cplex_3()
{
	int i, j, m;
	char instance[2000];
	sprintf_s(instance, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P1-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream resufile(instance, ios::app);
	float objvalue1, objvalue2;
	IloEnv env;
	try
	{
		printf("problem3 \n\n\n");
		IloModel model(env);
		//======Decision Variables Definition ==========//
		char varName[100];

		NumVarMatrix3d X(env, nbTeam); //������߱�������
		for (m = 0; m < nbTeam; m++)
		{
			X[m] = NumVarMatrix(env, nbNode + 1);
			for (i = 0; i < nbNode + 1; i++)
				X[m][i] = IloNumVarArray(env, nbNode + 1, 0, 1, ILOINT); //FLOAT INT
		}
		IloNumVar Cmax(env, 0, IloInfinity);//total completion time

		IloNumVarArray C(env, nbNode + 1, 0, IloInfinity); //���岿����ά�����ʱ��

		//======formulation ==========//
		model.add(IloMinimize(env, Cmax));// minimizing the total completion time

		IloExpr obj2(env);
		IloExpr obj22(env);
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					obj2 += f1 * dis[i][j] * X[m][i][j];
		for (j = 1; j < nbNode + 1; j++)
			obj22 += f3 * C[j];
		model.add(obj2 + f2 * nbTeam + obj22 <= LANMTA);
		//model.add(obj2 + f2 * nbTeam  <= LANMTA);
		obj2.clear();
		obj22.clear();


		IloExpr sumPass(env);//Լ��1  ��ʾÿ������ֻ����һ��ά�������ṩ����
		for (j = 1; j < nbNode + 1; j++)
		{
			for (m = 0; m < nbTeam; m++)
				for (i = 0; i < nbNode + 1; i++)
					if (i != j)
					{
						sumPass += X[m][i][j];
					}
			model.add(sumPass == 1);
			sumPass.clear();
		}


		IloExpr sumP1(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP1 += X[m][0][i];
			}
			model.add(sumP1 == 1);
			sumP1.clear();
		}
		IloExpr sumP2(env);//Լ��3  ��ʾÿ����Ԯ���鶼���Իص���Ԯ����
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP2 += X[m][i][0];
			}
			model.add(sumP2 == 1);
			sumP2.clear();
		}


		IloExpr sumPre(env);//Լ��5 ����ƽ��Լ������Ч����ʽ
		IloExpr sumAft(env);
		for (m = 0; m < nbTeam; m++)
			for (j = 1; j < nbNode + 1; j++)
			{
				for (i = 0; i < nbNode + 1; i++)
				{
					sumPre += X[m][i][j];
					sumAft += X[m][j][i];
				}
				model.add(sumPre == sumAft);
				model.add(sumPre <= 1);
				model.add(sumAft <= 1);
				sumPre.clear();
				sumAft.clear();
			}

		IloExpr sumTime(env);//Լ��6 ������ʻʱ��Լ��
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					sumTime += X[m][i][j];
			model.add(sumTime <= Q[m]);
			sumTime.clear();
		}


		for (m = 0; m < nbTeam; m++)//��Ԯ���ȼ�Լ��
		{
			for (i = 1; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					if (i > j)
					{
						model.add(X[m][i][j] == 0);
					}

		}

		IloExpr sumP01(env);//Լ��2  ά�����ȼ�Լ��
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbTeam + 1; i++)
			{
				sumP01 += X[m][0][i];
			}
		model.add(sumP01 == nbTeam);
		sumP1.clear();



		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j] + X[m][j][i] <= 1);

		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j]);

		/*=======================����ά��ʱ��============================*/

		model.add(C[0] == 0);

		for (i = 1; i < nbTeam + 1; i++)
		{
			//IloExpr sums1(env);
			for (m = 0; m < nbTeam; m++)
				/*{
					sums1 += dis[0][i] / Vm[m] * X[m][0][i];
				}*/
				model.add(C[i] >= dis[0][i] / Vm[m] * X[m][0][i] + p[i]);
			//sums1.clear();
		}





		for (i = 1; i < nbNode + 1; i++)// ����ά��������ɲ���i��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					if (i > j)
					{
						model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (X[m][j][i] - 1));
						//model.add(C[i] <= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (1 - X[m][j][i]));
					}


		for (i = 1; i < nbNode + 1; i++)
		{
			model.add(Cmax >= C[i]);
		}

		IloExpr temp8(env); //��Ч����ʽ1
		for (j = 1; j < nbNode + 1; j++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (m = 0; m < nbTeam; m++)
				{
					if (i != j)
					{
						temp8 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp8);
			temp8.clear();
		}


		IloExpr temp81(env);//��Ч����ʽ2
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
				{
					if (i != j)
					{
						temp81 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp81);
			temp81.clear();
		}

		//IloExpr sumP13(env);//Լ��2  ģ��P2��
		//for (i = 1; i < nbNode + 1; i++)
		//{
		//	for (j = 0; j < nbNode + 1; j++)
		//		for (m = 0; m < nbTeam; m++)
		//		{
		//			sumP13 += X[m][j][i];
		//		}

		//	model.add(C[i] >= (u[i] + p[i]) * sumP13);
		//	sumP13.clear();
		//}

		//for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
		//	for (j = 0; j < nbNode + 1; j++)
		//		for (m = 0; m < nbTeam; m++)
		//			model.add(C[i] >= u[i] + p[i]);


		//=====solve the model and parameter setting====//
		IloCplex cplex(model); // or IloCplex cplex(env); cplex.extract(model);
		cplex.setParam(IloCplex::TiLim, myTiLim);
		cplex.setParam(IloCplex::ClockType, 1);
		cplex.setParam(IloCplex::WorkMem, 512);
		cplex.setParam(IloCplex::TreLim, 1024);
		cplex.setParam(IloCplex::NodeFileInd, 2);//to aviod out of memory 
		cplex.setParam(IloCplex::Symmetry, 2);
		cplex.exportModel("FFS.lp");
		cplex.solve();

		if (!cplex.solve())
		{
			cout << "Cplex_solve error!" << endl;
			throw(-1);
		}
		resufile << endl;
		resufile << " results " << endl;
		cout << "\n\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		cout << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		resufile << "\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		resufile << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		resufile << "iterations:  " << cplex.getNiterations() << "  " << "searched nodes: " << cplex.getNnodes() << endl;


		double AcDri1[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri1[m] = 0;
			cout << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						cout << i << "  " << j << "   ";
						AcDri1[m] += dis[i][j];
					}
			cout << "   " << AcDri1[m];
		}
		resufile << " route " << endl;
		double AcDri[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri[m] = 0;
			resufile << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						resufile << i << "  " << j << "   ";
						AcDri[m] += dis[i][j];
					}
			resufile << "   " << AcDri[m];
		}
		resufile << "\n " << endl;
		resufile << " C_j " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				resufile << cplex.getValue(C[j]) << "  ";
			}
		cout << endl;
		cout << " ά�����ʱ�� " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				cout << cplex.getValue(C[j]) << "  ";
			}

		resufile << " C_total " << endl;
		/*double CC = 0;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				CC += f3 * cplex.getValue(C[j]);
			}
		resufile << "ά���ɱ� " << CC << endl;*/
		//==========================================
		objvalue1 = cplex.getValue(Cmax);
		objvalue2 = 0;
		double ff2 = 0;
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					objvalue2 += f1 * dis[i][j] * cplex.getValue(X[m][i][j]);
		for (j = 1; j < nbNode + 1; j++)
			ff2 += f3 * cplex.getValue(C[j]);
		OBJ1 = objvalue1;
		OBJ2 = objvalue2 + f2 * nbTeam + ff2;

	}
	catch (IloException& e) { cerr << " ERROR: " << e << endl; }
	catch (...) { cerr << " ERROR" << endl; }
	env.end();
	return 0;
}

int FindOptM_Cplex_4()
{

	int i, j, m;
	char instance1[2000];
	sprintf_s(instance1, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P2-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream outputfile(instance1, ios::app);
	float objvalue1, objvalue2;
	IloEnv env;
	try
	{
		printf("problem1\n\n\n\n ");
		outputfile << "problem1 : " << endl;
		IloModel model(env);
		//======Decision Variables Definition ==========//

		//======Decision Variables Definition ==========//
		NumVarMatrix3d X(env, nbTeam); //������߱�������
		for (m = 0; m < nbTeam; m++)
		{
			X[m] = NumVarMatrix(env, nbNode + 1);
			for (i = 0; i < nbNode + 1; i++)
				X[m][i] = IloNumVarArray(env, nbNode + 1, 0, 1, ILOINT); //FLOAT INT
		}
		IloNumVar Cmax(env, 0, IloInfinity);//total completion time

		IloNumVarArray C(env, nbNode + 1, 0, IloInfinity); //���岿����ά�����ʱ��

		//======formulation ==========//
		model.add(IloMinimize(env, Cmax));// minimizing the total completion time


		IloExpr sumPass(env);//Լ��1  ��ʾÿ������ֻ����һ��ά�������ṩ����
		for (j = 1; j < nbNode + 1; j++)
		{
			for (m = 0; m < nbTeam; m++)
				for (i = 0; i < nbNode + 1; i++)
					if (i != j)
					{
						sumPass += X[m][i][j];
					}
			model.add(sumPass == 1);
			sumPass.clear();
		}


		IloExpr sumP1(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP1 += X[m][0][i];
			}
			model.add(sumP1 == 1);
			sumP1.clear();
		}
		IloExpr sumP2(env);//Լ��3  ��ʾÿ����Ԯ���鶼���Իص���Ԯ����
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP2 += X[m][i][0];
			}
			model.add(sumP2 == 1);
			sumP2.clear();
		}


		IloExpr sumPre(env);//Լ��5 ����ƽ��Լ������Ч����ʽ
		IloExpr sumAft(env);
		for (m = 0; m < nbTeam; m++)
			for (j = 1; j < nbNode + 1; j++)
			{
				for (i = 0; i < nbNode + 1; i++)
				{
					sumPre += X[m][i][j];
					sumAft += X[m][j][i];
				}
				model.add(sumPre == sumAft);
				model.add(sumPre <= 1);
				model.add(sumAft <= 1);
				sumPre.clear();
				sumAft.clear();
			}

		IloExpr sumTime(env);//Լ��6 ������ʻʱ��Լ��
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					sumTime += X[m][i][j];
			model.add(sumTime <= Q[m]);
			sumTime.clear();
		}


		for (m = 0; m < nbTeam; m++)//��Ԯ���ȼ�Լ��
		{
			for (i = 1; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					if (i > j)
					{
						model.add(X[m][i][j] == 0);
					}

		}

		IloExpr sumP01(env);//Լ��2  ά�����ȼ�Լ��
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbTeam + 1; i++)
			{
				sumP01 += X[m][0][i];
			}
		model.add(sumP01 == nbTeam);
		sumP1.clear();



		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j] + X[m][j][i] <= 1);

		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j]);

		/*=======================����ά��ʱ��============================*/

		model.add(C[0] == 0);

		//for (i = 1; i < nbTeam + 1; i++)
		//{
		//	//IloExpr sums1(env);
		//	for (m = 0; m < nbTeam; m++)
		//	/*{
		//		sums1 += dis[0][i] / Vm[m] * X[m][0][i];
		//	}*/
		//	model.add(C[i] >= dis[0][i] / Vm[m] * X[m][0][i] + p[i]);
		//	//sums1.clear();
		//}

		for (i = 1; i < nbTeam + 1; i++)
		{
			IloExpr sums1(env);
			for (m = 0; m < nbTeam; m++)
			{
				sums1 += dis[0][i] / Vm[m] * X[m][0][i];
			}
			model.add(C[i] >= sums1 + p[i]);
			sums1.clear();
		}

		//IloExpr sumP11(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		//for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
		//	for (j = 0; j < nbNode + 1; j++)
		//	{
		//		for (m = 0; m < nbTeam; m++)
		//			//sumP11 += X[m][j][i];	
		//		if (i > j)
		//		{
		//			sumP11 += X[m][j][i];
		//		}
		//		model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (sumP11 - 1));
		//		sumP11.clear();
		//		
			//}

		for (i = 1; i < nbNode + 1; i++)// ����ά��������ɲ���i��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					if (i > j)
					{
						model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (X[m][j][i] - 1));
						//model.add(C[i] <= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (1 - X[m][j][i]));
					}


		for (i = 1; i < nbNode + 1; i++)
		{
			model.add(Cmax >= C[i]);
		}



		IloExpr temp8(env); //��Ч����ʽ1
		for (j = 1; j < nbNode + 1; j++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (m = 0; m < nbTeam; m++)
				{
					if (i != j)
					{
						temp8 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp8);
			temp8.clear();
		}


		IloExpr temp81(env);//��Ч����ʽ2
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
				{
					if (i != j)
					{
						temp81 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp81);
			temp81.clear();
		}




		IloExpr sumP13(env);//Լ��2  ģ��P2��
		for (i = 1; i < nbNode + 1; i++)
		{
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
				{
					sumP13 += X[m][j][i];
				}

			model.add(C[i] >= (u[i] + p[i]) * sumP13);
			sumP13.clear();
		}

		for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
			//	for (j = 0; j < nbNode + 1; j++)
				//	for (m = 0; m < nbTeam; m++)
			model.add(C[i] >= u[i] + p[i]);

		//=====solve the model and parameter setting====//
		IloCplex cplex(model); // or IloCplex cplex(env); cplex.extract(model);
		cplex.setParam(IloCplex::TiLim, myTiLim);
		cplex.setParam(IloCplex::ClockType, 1);
		cplex.setParam(IloCplex::WorkMem, 512);
		cplex.setParam(IloCplex::TreLim, 1024);
		cplex.setParam(IloCplex::NodeFileInd, 2);//to aviod out of memory 
		cplex.setParam(IloCplex::Symmetry, 2);
		cplex.exportModel("FFS.lp");
		cplex.solve();

		if (!cplex.solve())
		{
			cout << "Cplex_solve error!" << endl;
			throw(-1);
		}
		outputfile << endl;
		outputfile << " results " << endl;
		cout << "\n\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		cout << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		outputfile << "\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		outputfile << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		outputfile << "iterations:  " << cplex.getNiterations() << "  " << "searched nodes: " << cplex.getNnodes() << endl;


		double AcDri1[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri1[m] = 0;
			cout << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						cout << i << "  " << j << "   ";
						AcDri1[m] += dis[i][j];
					}
			cout << "   " << AcDri1[m];
		}
		outputfile << " Route " << endl;
		double AcDri[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri[m] = 0;
			outputfile << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						outputfile << i << "  " << j << "   ";
						AcDri[m] += dis[i][j];
					}
			outputfile << "   " << AcDri[m];
		}

		outputfile << " C_j " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				outputfile << cplex.getValue(C[j]) << "  ";
			}
		cout << endl;
		cout << " ά�����ʱ�� " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				cout << cplex.getValue(C[j]) << "  ";
			}

		double CC = 0;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				CC += f3 * cplex.getValue(C[j]);
			}
		outputfile << "ά���ɱ� " << CC << endl;
		//====================================================
		objvalue1 = cplex.getValue(Cmax);
		objvalue2 = 0;
		double ff2 = 0;
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					objvalue2 += f1 * dis[i][j] * cplex.getValue(X[m][i][j]);
		for (j = 1; j < nbNode + 1; j++)
			ff2 += f3 * cplex.getValue(C[j]);

		minf1 = objvalue1;
		maxf2 = objvalue2 + f2 * nbTeam + ff2;
		upperbound = maxf2;



	}
	catch (IloException& e) { cerr << " ERROR: " << e << endl; }
	catch (...) { cerr << " ERROR" << endl; }
	env.end();
	return 0;
}

int FindOptM_Cplex_5()
{
	int i, j, m;
	char instance1[2000];
	sprintf_s(instance1, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P2-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream outputfile(instance1, ios::app);
	float objvalue1, objvalue2;
	IloEnv env;
	try
	{
		printf("problem2 \n\n\n");
		outputfile << "problem2 : " << endl;
		IloModel model(env);
		//======Decision Variables Definition ==========//
		char varName[100];

		NumVarMatrix3d X(env, nbTeam); //������߱�������
		for (m = 0; m < nbTeam; m++)
		{
			X[m] = NumVarMatrix(env, nbNode + 1);
			for (i = 0; i < nbNode + 1; i++)
				X[m][i] = IloNumVarArray(env, nbNode + 1, 0, 1, ILOINT); //FLOAT INT
		}
		IloNumVar Cmax(env, 0, IloInfinity);//total completion time

		IloNumVarArray C(env, nbNode + 1, 0.0, IloInfinity); //���岿����ά�����ʱ��

		//======formulation ==========//
		//Objective 1
		//IloObjective obj1(env, Cmax, IloObjective::Minimize);
		//model.add(obj1);
		//model.add(IloMinimize(env, Cmax));// minimizing the total completion time

		IloExpr obj2(env);
		IloExpr obj22(env);
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					obj2 += f1 * dis[i][j] * X[m][i][j];
		for (j = 1; j < nbNode + 1; j++)
			obj22 += f3 * C[j];
		//model.add(IloMinimize(env, obj2 + f2 * nbTeam));
		model.add(IloMinimize(env, obj2 + f2 * nbTeam + obj22));

		IloExpr sumPass(env);//Լ��1  ��ʾÿ������ֻ����һ��ά�������ṩ����
		for (j = 1; j < nbNode + 1; j++)
		{
			for (m = 0; m < nbTeam; m++)
				for (i = 0; i < nbNode + 1; i++)
					if (i != j)
					{
						sumPass += X[m][i][j];
					}
			model.add(sumPass == 1);
			sumPass.clear();
		}


		IloExpr sumP1(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP1 += X[m][0][i];
			}
			model.add(sumP1 == 1);
			sumP1.clear();
		}
		IloExpr sumP2(env);//Լ��3  ��ʾÿ����Ԯ���鶼���Իص���Ԯ����
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP2 += X[m][i][0];
			}
			model.add(sumP2 == 1);
			sumP2.clear();
		}


		IloExpr sumPre(env);//Լ��5 ����ƽ��Լ������Ч����ʽ
		IloExpr sumAft(env);
		for (m = 0; m < nbTeam; m++)
			for (j = 1; j < nbNode + 1; j++)
			{
				for (i = 0; i < nbNode + 1; i++)
				{
					sumPre += X[m][i][j];
					sumAft += X[m][j][i];
				}
				model.add(sumPre == sumAft);
				model.add(sumPre <= 1);
				model.add(sumAft <= 1);
				sumPre.clear();
				sumAft.clear();
			}

		IloExpr sumTime(env);//Լ��6 ������ʻʱ��Լ��
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					sumTime += X[m][i][j];
			model.add(sumTime <= Q[m]);
			sumTime.clear();
		}


		for (m = 0; m < nbTeam; m++)//��Ԯ���ȼ�Լ��
		{
			for (i = 1; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					if (i > j)
					{
						model.add(X[m][i][j] == 0);
					}

		}

		IloExpr sumP01(env);//Լ��2  ά�����ȼ�Լ��
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbTeam + 1; i++)
			{
				sumP01 += X[m][0][i];
			}
		model.add(sumP01 == nbTeam);
		sumP1.clear();



		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j] + X[m][j][i] <= 1);

		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j]);

		/*=======================����ά��ʱ��============================*/

		model.add(C[0] == 0);

		for (i = 1; i < nbTeam + 1; i++)
		{
			//IloExpr sums1(env);
			for (m = 0; m < nbTeam; m++)
				/*{
					sums1 += dis[0][i] / Vm[m] * X[m][0][i];
				}*/
				model.add(C[i] >= dis[0][i] / Vm[m] * X[m][0][i] + p[i]);
			//sums1.clear();
		}



		for (i = 1; i < nbNode + 1; i++)// ����ά��������ɲ���i��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					if (i > j)
					{
						model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (X[m][j][i] - 1));
						//model.add(C[i] <= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (1 - X[m][j][i]));
					}


		for (i = 1; i < nbNode + 1; i++)
		{
			model.add(Cmax >= C[i]);
		}

		IloExpr temp8(env); //��Ч����ʽ1
		for (j = 1; j < nbNode + 1; j++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (m = 0; m < nbTeam; m++)
				{
					if (i != j)
					{
						temp8 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp8);
			temp8.clear();
		}


		IloExpr temp81(env);//��Ч����ʽ2
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
				{
					if (i != j)
					{
						temp81 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp81);
			temp81.clear();
		}

		IloExpr sumP13(env);//Լ��2  ģ��P2��
		for (i = 1; i < nbNode + 1; i++)
		{
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
				{
					sumP13 += X[m][j][i];
				}

			model.add(C[i] >= (u[i] + p[i]) * sumP13);
			sumP13.clear();
		}

		for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(C[i] >= u[i] + p[i]);

		//=====solve the model and parameter setting====//
		IloCplex cplex(model); // or IloCplex cplex(env); cplex.extract(model);
		cplex.setParam(IloCplex::TiLim, myTiLim);
		cplex.setParam(IloCplex::ClockType, 1);
		cplex.setParam(IloCplex::WorkMem, 512);
		cplex.setParam(IloCplex::TreLim, 1024);
		cplex.setParam(IloCplex::NodeFileInd, 2);//to aviod out of memory 
		cplex.setParam(IloCplex::Symmetry, 2);
		cplex.exportModel("FFS.lp");
		cplex.solve();

		if (!cplex.solve())
		{
			cout << "Cplex_solve error!" << endl;
			throw(-1);
		}
		outputfile << endl;
		outputfile << " results " << endl;
		cout << "\n\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		cout << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		outputfile << "\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		outputfile << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		outputfile << "iterations:  " << cplex.getNiterations() << "  " << "searched nodes: " << cplex.getNnodes() << endl;


		double AcDri1[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri1[m] = 0;
			cout << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						cout << i << "  " << j << "   ";
						AcDri1[m] += dis[i][j];
					}
			cout << "   " << AcDri1[m];
		}
		outputfile << " Route " << endl;
		double AcDri[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri[m] = 0;
			outputfile << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						outputfile << i << "  " << j << "   ";
						AcDri[m] += dis[i][j];
					}
			outputfile << "   " << AcDri[m];
		}

		outputfile << " C_j " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				outputfile << cplex.getValue(C[j]) << "  ";
			}
		cout << endl;
		cout << " ά�����ʱ�� " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				cout << cplex.getValue(C[j]) << "  ";
			}
		double CC = 0;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				CC += f3 * cplex.getValue(C[j]);
			}
		outputfile << "ά���ɱ� " << CC << endl;

		//==========================================
		objvalue1 = cplex.getValue(Cmax);

		objvalue2 = 0;
		double ff2 = 0;
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					objvalue2 += f1 * dis[i][j] * cplex.getValue(X[m][i][j]);
		for (j = 1; j < nbNode + 1; j++)
			ff2 += f3 * cplex.getValue(C[j]);
		maxf1 = objvalue1;
		minf2 = objvalue2 + f2 * nbTeam + ff2;
		lowerbound = objvalue2 + f2 * nbTeam + ff2;

	}
	catch (IloException& e) { cerr << " ERROR: " << e << endl; }
	catch (...) { cerr << " ERROR" << endl; }
	env.end();
	return 0;
}

int FindOptM_Cplex_6()
{
	int i, j, m;
	char instance1[2000];
	sprintf_s(instance1, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P2-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream outputfile(instance1, ios::app);
	float objvalue1, objvalue2;
	IloEnv env;
	try
	{
		printf("problem3 \n\n\n");
		IloModel model(env);
		//======Decision Variables Definition ==========//
		char varName[100];

		NumVarMatrix3d X(env, nbTeam); //������߱�������
		for (m = 0; m < nbTeam; m++)
		{
			X[m] = NumVarMatrix(env, nbNode + 1);
			for (i = 0; i < nbNode + 1; i++)
				X[m][i] = IloNumVarArray(env, nbNode + 1, 0, 1, ILOINT); //FLOAT INT
		}
		IloNumVar Cmax(env, 0, IloInfinity);//total completion time

		IloNumVarArray C(env, nbNode + 1, 0, IloInfinity); //���岿����ά�����ʱ��

		//======formulation ==========//
		model.add(IloMinimize(env, Cmax));// minimizing the total completion time

		IloExpr obj2(env);
		IloExpr obj22(env);
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					obj2 += f1 * dis[i][j] * X[m][i][j];
		for (j = 1; j < nbNode + 1; j++)
			obj22 += f3 * C[j];
		model.add(obj2 + f2 * nbTeam + obj22 <= LANMTA);
		//model.add(obj2 + f2 * nbTeam <= LANMTA);
		obj2.clear();
		obj22.clear();


		IloExpr sumPass(env);//Լ��1  ��ʾÿ������ֻ����һ��ά�������ṩ����
		for (j = 1; j < nbNode + 1; j++)
		{
			for (m = 0; m < nbTeam; m++)
				for (i = 0; i < nbNode + 1; i++)
					if (i != j)
					{
						sumPass += X[m][i][j];
					}
			model.add(sumPass == 1);
			sumPass.clear();
		}


		IloExpr sumP1(env);//Լ��2  ��ʾÿ����Ԯ���鶼�Ӿ�Ԯ���ĳ���
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP1 += X[m][0][i];
			}
			model.add(sumP1 == 1);
			sumP1.clear();
		}
		IloExpr sumP2(env);//Լ��3  ��ʾÿ����Ԯ���鶼���Իص���Ԯ����
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
			{
				sumP2 += X[m][i][0];
			}
			model.add(sumP2 == 1);
			sumP2.clear();
		}


		IloExpr sumPre(env);//Լ��5 ����ƽ��Լ������Ч����ʽ
		IloExpr sumAft(env);
		for (m = 0; m < nbTeam; m++)
			for (j = 1; j < nbNode + 1; j++)
			{
				for (i = 0; i < nbNode + 1; i++)
				{
					sumPre += X[m][i][j];
					sumAft += X[m][j][i];
				}
				model.add(sumPre == sumAft);
				model.add(sumPre <= 1);
				model.add(sumAft <= 1);
				sumPre.clear();
				sumAft.clear();
			}

		IloExpr sumTime(env);//Լ��6 ������ʻʱ��Լ��
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					sumTime += X[m][i][j];
			model.add(sumTime <= Q[m]);
			sumTime.clear();
		}


		for (m = 0; m < nbTeam; m++)//��Ԯ���ȼ�Լ��
		{
			for (i = 1; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
					if (i > j)
					{
						model.add(X[m][i][j] == 0);
					}

		}

		IloExpr sumP01(env);//Լ��2  ά�����ȼ�Լ��
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbTeam + 1; i++)
			{
				sumP01 += X[m][0][i];
			}
		model.add(sumP01 == nbTeam);
		sumP1.clear();



		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j] + X[m][j][i] <= 1);

		for (i = 0; i < nbNode + 1; i++)//��Լ����12��//Լ��12
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(X[m][i][j]);

		/*=======================����ά��ʱ��============================*/

		model.add(C[0] == 0);

		for (i = 1; i < nbTeam + 1; i++)
		{
			//IloExpr sums1(env);
			for (m = 0; m < nbTeam; m++)
				/*{
					sums1 += dis[0][i] / Vm[m] * X[m][0][i];
				}*/
				model.add(C[i] >= dis[0][i] / Vm[m] * X[m][0][i] + p[i]);
			//sums1.clear();
		}





		for (i = 1; i < nbNode + 1; i++)// ����ά��������ɲ���i��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					if (i > j)
					{
						model.add(C[i] >= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (X[m][j][i] - 1));
						//model.add(C[i] <= C[j] + p[i] + dis[j][i] / Vm[m] + bigM * (1 - X[m][j][i]));
					}


		for (i = 1; i < nbNode + 1; i++)
		{
			model.add(Cmax >= C[i]);
		}

		IloExpr temp8(env); //��Ч����ʽ1
		for (j = 1; j < nbNode + 1; j++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (m = 0; m < nbTeam; m++)
				{
					if (i != j)
					{
						temp8 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp8);
			temp8.clear();
		}


		IloExpr temp81(env);//��Ч����ʽ2
		for (m = 0; m < nbTeam; m++)
		{
			for (i = 0; i < nbNode + 1; i++)
				for (j = 1; j < nbNode + 1; j++)
				{
					if (i != j)
					{
						temp81 += (dis[i][j] / Vm[m] + p[j]) * X[m][i][j];
					}
				}
			model.add(Cmax >= temp81);
			temp81.clear();
		}

		IloExpr sumP13(env);//Լ��2  ģ��P2��
		for (i = 1; i < nbNode + 1; i++)
		{
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
				{
					sumP13 += X[m][j][i];
				}

			model.add(C[i] >= (u[i] + p[i]) * sumP13);
			sumP13.clear();
		}

		for (i = 1; i < nbNode + 1; i++)//Լ��7��8 ���㳵��������ֵ��ʱ��
			for (j = 0; j < nbNode + 1; j++)
				for (m = 0; m < nbTeam; m++)
					model.add(C[i] >= u[i] + p[i]);


		//=====solve the model and parameter setting====//
		IloCplex cplex(model); // or IloCplex cplex(env); cplex.extract(model);
		cplex.setParam(IloCplex::TiLim, myTiLim);
		cplex.setParam(IloCplex::ClockType, 1);
		cplex.setParam(IloCplex::WorkMem, 512);
		cplex.setParam(IloCplex::TreLim, 1024);
		cplex.setParam(IloCplex::NodeFileInd, 2);//to aviod out of memory 
		cplex.setParam(IloCplex::Symmetry, 2);
		cplex.exportModel("FFS.lp");
		cplex.solve();

		if (!cplex.solve())
		{
			cout << "Cplex_solve error!" << endl;
			throw(-1);
		}
		outputfile << endl;
		outputfile << " results " << endl;
		cout << "\n\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		cout << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		outputfile << "\nbest UB: " << cplex.getObjValue() << "   best LB: " << cplex.getBestObjValue() << endl;
		outputfile << "status:  " << cplex.getStatus() << "  " << "number of BinVars: " << cplex.getNbinVars() << "  " << "number of variables:" << cplex.getNcols() << "  " << "number of constraints: " << cplex.getNrows() << endl;
		outputfile << "iterations:  " << cplex.getNiterations() << "  " << "searched nodes: " << cplex.getNnodes() << endl;


		double AcDri1[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri1[m] = 0;
			cout << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						cout << i << "  " << j << "   ";
						AcDri1[m] += dis[i][j];
					}
			cout << "   " << AcDri1[m];
		}
		outputfile << " route " << endl;
		double AcDri[nbTeam];
		for (m = 0; m < nbTeam; m++)
		{
			AcDri[m] = 0;
			outputfile << "\n" << "-" << m << "-th: ";
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					if (cplex.getValue(X[m][i][j]) > 0.5)
					{
						outputfile << i << "  " << j << "   ";
						AcDri[m] += dis[i][j];
					}
			outputfile << "   " << AcDri[m];
		}
		outputfile << "\n " << endl;
		outputfile << " C_j " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				outputfile << cplex.getValue(C[j]) << "  ";
			}
		cout << endl;
		cout << " ά�����ʱ�� " << endl;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				//CC == cplex.getValue(C[j]);
				cout << cplex.getValue(C[j]) << "  ";
			}

		outputfile << " C_total " << endl;
		/*double CC = 0;
		for (j = 0; j < nbNode + 1; j++)
			if (cplex.getValue(C[j]) > 0.0)
			{
				CC += f3 * cplex.getValue(C[j]);
			}
		outputfile << "ά���ɱ� " << CC << endl;*/
		//==========================================
		objvalue1 = cplex.getValue(Cmax);
		objvalue2 = 0;
		double ff2 = 0;
		for (m = 0; m < nbTeam; m++)
			for (i = 0; i < nbNode + 1; i++)
				for (j = 0; j < nbNode + 1; j++)
					objvalue2 += f1 * dis[i][j] * cplex.getValue(X[m][i][j]);
		for (j = 1; j < nbNode + 1; j++)
			ff2 += f3 * cplex.getValue(C[j]);
		OBJ1 = objvalue1;
		OBJ2 = objvalue2 + f2 * nbTeam + ff2;

	}
	catch (IloException& e) { cerr << " ERROR: " << e << endl; }
	catch (...) { cerr << " ERROR" << endl; }
	env.end();
	return 0;
}


float max(float sumu[], int length)
{
	int i, index;
	float max = 0;

	index = 0;
	for (i = 0; i < length; i++)
	{
		if (sumu[i] < 10000000)
		{
			if (sumu[i] > max)
			{
				max = sumu[i];
				index = i;
			}

		}
	}
	MAX = max; //MAX is a global variable
	Index = index;

	return MAX;
}


int main()
{
	FILE* out;
	char instance[2000];
	sprintf_s(instance, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P1-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream resufile(instance, ios::app);
	char instance1[2000];
	sprintf_s(instance1, "E:\\paper\\Aero-engine-maintenance\\IEC-jieguo\\IEC��Ŀ��ά��P2-IISE--%d-%d-revised.txt", nbNode, nbTeam);
	ofstream outputfile(instance1, ios::app);
	/*char instance1[2000];
	sprintf_s(instance1, "E:\\paper\\components-maintance\\IISE-jieguo-revised\\ά��P2-C_max-IISE-%d-%d.txt", nbNode, nbTeam);
	ofstream outfile(instance1, ios::app);*/
	int nbnetwork = 1;
	int nbe;
	int i, j, m;
	double timeCPU;
	double timeCPU_average = 0;
	resufile << "\n\n=========The original model P1 is solved===========" << endl;



	IloEnv env;
	IloTimer timer(env);
	timer.start();

	initialize();
	clock_t start, end;
	start = clock();
	end = clock();


	for (numth = 0; numth < nbnetwork; numth++)
	{
		cout << "numth=" << numth << endl;
		initialize();

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		FindOptM_Cplex_1(); //di yi ge han shu qiu de jie dai ru di er ge mu biao han shu: upperbound

		printf("\n*********the min f 1 =: %5.3f\n", minf1);
		resufile << "minf1 = " << minf1 << endl;
		resufile << "maxf2 = " << maxf2 << endl;
		printf("\n*********the max f 2 =: %5.3f\n", maxf2);
		printf("\n");


		FindOptM_Cplex_2(); //di er ge mu biao han shu zhi: lowerbound
		printf("\n*********the max f 1 =: %5.3f\n", maxf1);
		printf("\n");
		printf("\n*********the min f 2 =: %5.3f\n", minf2);
		printf("\n\n\n");
		resufile << "maxf1 = " << maxf1 << endl;
		resufile << "minf2 = " << minf2 << endl << endl << endl;
		double R = 0.00;
		nbe = 1;
		LANMTA = maxf2;
		R = (maxf2 - minf2) / 10;
		//LANMTA = 1706;
		cout << "nbe=" << nbe << endl;
		resufile << "nbe=" << nbe << endl;
		cout << "LANMAT = " << LANMTA << endl;
		resufile << "LANMAT = " << LANMTA << endl;
		while (LANMTA >= minf2)
		{
			FindOptM_Cplex_3();
			printf(" OBJ1 = %3.2f", OBJ1);
			printf("\n");
			printf("OBJ2 = %3.2f", OBJ2);
			printf("\n");
			resufile << "OBJ1 = " << OBJ1 << endl;
			resufile << "OBJ2 = " << OBJ2 << endl << endl << endl;

			nbe = nbe + 1;
			LANMTA = OBJ2 - R;
			cout << "nbe=" << nbe << endl;
			resufile << "nbe=" << nbe << endl;
			cout << "LANMAT = " << LANMTA << endl;
			resufile << "LANMAT = " << LANMTA << endl;
		}

		end = clock();

		timeCPU = timer.getTime();
		timeCPU_average += timeCPU;
		resufile << "CPU_time is: " << timeCPU << "\t";
		resufile << "Clock_t_time is: " << (end - start) / double(CLK_TCK) << endl;
		cout << "\nCPU_time is: " << timeCPU << endl;
		cout << "Clock_t_time is: " << (end - start) / double(CLK_TCK) << endl;
	}
	resufile << "The average CPU_time of five instances is: " << timeCPU_average / numtest;
	resufile.close();


	/*int nbnetwork = 1;
	int nbe;
	int i, j, m;*/
	double timeCPU1;
	double timeCPU_average1 = 0;
	outputfile << "\n\n=========The original model P2 is solved===========" << endl;



	//IloEnv env;
	//IloTimer timer(env);
	//timer.start();

	//initialize();
	//clock_t start1, end1;
	//start1 = clock();
	//end1 = clock();


	//for (numth = 0; numth < nbnetwork; numth++)
	//{
	//	cout << "numth=" << numth << endl;
	//	initialize();

	//	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//	FindOptM_Cplex_4(); //di yi ge han shu qiu de jie dai ru di er ge mu biao han shu: upperbound

	//	printf("\n*********the min f 1 =: %5.3f\n", minf1);
	//	outputfile << "minf1 = " << minf1 << endl;
	//	outputfile << "maxf2 = " << maxf2 << endl;
	//	printf("\n*********the max f 2 =: %5.3f\n", maxf2);
	//	printf("\n");


	//	FindOptM_Cplex_5(); //di er ge mu biao han shu zhi: lowerbound
	//	printf("\n*********the max f 1 =: %5.3f\n", maxf1);
	//	printf("\n");
	//	printf("\n*********the min f 2 =: %5.3f\n", minf2);
	//	printf("\n\n\n");
	//	outputfile << "maxf1 = " << maxf1 << endl;
	//	outputfile << "minf2 = " << minf2 << endl << endl << endl;
	//	double R = 0.00;
	//	nbe = 1;
	//	LANMTA = maxf2;
	//	R = (maxf2 - minf2) / 10;
	//	//LANMTA = 1706;
	//	cout << "nbe=" << nbe << endl;
	//	outputfile << "nbe=" << nbe << endl;
	//	cout << "LANMAT = " << LANMTA << endl;
	//	resufile << "LANMAT = " << LANMTA << endl;
	//	while (LANMTA >= minf2)
	//	{
	//		FindOptM_Cplex_6();
	//		printf(" OBJ1 = %3.2f", OBJ1);
	//		printf("\n");
	//		printf("OBJ2 = %3.2f", OBJ2);
	//		printf("\n");
	//		outputfile << "OBJ1 = " << OBJ1 << endl;
	//		outputfile << "OBJ2 = " << OBJ2 << endl << endl << endl;

	//		nbe = nbe + 1;
	//		LANMTA = OBJ2 - R;
	//		cout << "nbe=" << nbe << endl;
	//		outputfile << "nbe=" << nbe << endl;
	//		cout << "LANMAT = " << LANMTA << endl;
	//		outputfile << "LANMAT = " << LANMTA << endl;
	//	}

	//	end1 = clock();

	//	timeCPU1 = timer.getTime();
	//	timeCPU_average1 += timeCPU1;
	//	outputfile << "CPU_time is: " << timeCPU1 << "\t";
	//	outputfile << "Clock_t_time is: " << (end1 - start1) / double(CLK_TCK) << endl;
	//	cout << "\nCPU_time is: " << timeCPU1 << endl;
	//	cout << "Clock_t_time is: " << (end1 - start1) / double(CLK_TCK) << endl;
	//}
	//outputfile << "The average CPU_time of five instances is: " << timeCPU_average1 / numtest;
	//outputfile.close();

	return 0;

}

